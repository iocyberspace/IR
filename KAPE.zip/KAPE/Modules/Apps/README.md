# .\KapeFiles\Modules\Apps

Modules that relate to third-party software that isn't hosted on GitHub are stored in the Apps folder.

Modules that relates to third-party software that is hosted on GitHub are stored in the GitHub subfolder. 
